// Used by ThisExample.cpp 
class Example
{
   int x;
 public:
   Example(int a){ x = a;}
   void setValue(int);
   void printAddressAndValue();
};
